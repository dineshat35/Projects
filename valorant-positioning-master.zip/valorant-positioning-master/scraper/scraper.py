#!/usr/bin/env python3
import json
import zlib
import time
import argparse
import urllib.request
import mysql.connector

parser = argparse.ArgumentParser()
parser.add_argument("--key", help="The Riot API key (RGAPI-xxxx...)")
args = parser.parse_args()

KEY = args.key

# 20 requests every 1 seconds
# 100 requests every 2 minutes
# we need 0.1 extra seconds to be safe
limit = 100.0 / 120.0 + 0.1

db_config = {
    'user': 'root',
    'password': 'root',
    'host': 'localhost',
    'port': '3306',
    'database': 'matches'
}
max_retries = 10
db_delay = 5
i = 0

while (i < max_retries):
    try:
        # connect to the mysql database
        mydb = mysql.connector.connect(**db_config)
        i = max_retries  # connection successful, break out
    except:
        print(
            f"Waiting for the mysql database to start... {i}")
        time.sleep(db_delay)
        i += 1


cursor = mydb.cursor()

queue_prefix = "https://na.api.riotgames.com/val/match/v1/recent-matches/by-queue/competitive?api_key="
match_data_prefix = "https://na.api.riotgames.com/val/match/v1/matches/"


def is_match_count_exceeded(cursor, max_matches=1000000):
    cursor.execute(f"SELECT COUNT(*) FROM matches")
    number_of_rows = cursor.fetchone()[0]
    print(f"Found {number_of_rows} matches in matches table")
    return number_of_rows > max_matches


while not is_match_count_exceeded(cursor=cursor):
    with urllib.request.urlopen(queue_prefix + KEY) as response:
        data = json.load(response)
        matchIds = data['matchIds']
        print(f"Grabbing {len(matchIds)} games")
        for matchId in matchIds:
            time.sleep(limit)
            match_url = f'{match_data_prefix}{matchId}?api_key={KEY}'
            # save match data to database
            try:
                with urllib.request.urlopen(match_url) as match_response:
                    zlib_compressed_match_data = zlib.compress(
                        match_response.read())
                    sql = "INSERT INTO matches (id, data) VALUES (%s, %s)"
                    val = (matchId, zlib_compressed_match_data)
                    cursor.execute(sql, val)
                    mydb.commit()
                    print(matchId)
            except Exception as e:
                print(e)
                print("Trying again...")
                time.sleep(10)

cursor.close()
mydb.close()
