create database matches;
use matches;

CREATE TABLE matches (
  id CHAR(36), -- length of Valorant match id
  data BLOB
);