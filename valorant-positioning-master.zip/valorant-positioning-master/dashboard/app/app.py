import plotly.express as px
from flask import Flask
import pandas as pd
import dash
from dash import Dash, dcc, html, Input, Output, State, html, ctx
import plotly.figure_factory as ff
import dash_bootstrap_components as dbc
import time
import plotly.graph_objects as go
import json
import numpy as np
import pymysql
from sqlalchemy import create_engine
from sqlalchemy import text
import random


server = Flask(__name__)
app = dash.Dash(server=server, external_stylesheets=[dbc.themes.FLATLY])
app.title = 'Dashboard'
app.layout = dbc.Table()

# mysql engine
engine = create_engine('mysql+pymysql://root:root@db/matches')

maps_query = 'SELECT displayName, displayIcon, mapUrl FROM maps'

with engine.begin() as conn:
    maps_df = pd.read_sql_query(sql=text(maps_query), con=conn)


app.layout = dbc.Container(
    fluid=True,
    children=[
        dbc.Row(
            dbc.Col(html.H2("Valorant Gunfight Predictor"))),
        dbc.Row(dbc.Col(
            children=[
                dcc.Dropdown(maps_df['displayName'].unique(
                ), id='map-dropdown', searchable=False, placeholder="Select map..."),
                dcc.Dropdown([], id='matchId-dropdown', placeholder="Select matchId...",)]
        )),
        dbc.Row(dbc.Col(
            children=[html.Div(
                id='graph-container',
                children=[
                    dcc.Graph(
                        id='graph',
                        responsive=True,
                        style={'width': 'auto', 'height': '80vh'},
                        figure=go.Figure(),
                        config=dict(
                            scrollZoom=True
                        )
                    ),
                ],
            )
            ],
        )),
        html.Pre(id='click-data'),
        html.Pre(id='relay-data'),
    ])


@app.callback(
    Output('click-data', 'children'),
    Input('graph', 'clickData'))
def display_hover_data(hoverData):
    return json.dumps(hoverData, indent=2)


@app.callback(
    Output('matchId-dropdown', 'options'),
    Output('matchId-dropdown', 'value'),
    Input('map-dropdown', 'value'),
)
def update_matchids(mapName: str):
    # map got updated
    if mapName != None and ctx.triggered_id == "map-dropdown":
        mapUrl = maps_df[maps_df['displayName'] == mapName]['mapUrl'].values[0]

        matches_df_query = '''
        SELECT matchId
        FROM kills
        WHERE map=:map_url
        GROUP BY matchId
        LIMIT 50;'''

        with engine.begin() as conn:
            matches_df = pd.read_sql_query(
                sql=text(matches_df_query), con=conn, params={"map_url": mapUrl})

        matchIds = matches_df['matchId'].values.tolist()
        return matchIds, matchIds[0]
    else:
        return [], None


@app.callback(
    Output('graph', 'figure'),
    Input('matchId-dropdown', 'value'),
    Input('graph', 'relayoutData'),
    State('map-dropdown', 'value'),
    State('graph', 'figure')
)
def update_output(matchId: str, relayoutData, mapName: str, fig: dict):
    print("Trigger", ctx.triggered_id, matchId, mapName)
    # map got updated
    if mapName != None and matchId != None:
        if ctx.triggered_id == "matchId-dropdown":
            mapImg = maps_df[maps_df['displayName']
                             == mapName]['displayIcon'].values[0]

            kills_df_query = '''
            SELECT *
            FROM kills
            WHERE matchId=:matchId;'''

            with engine.begin() as conn:
                filtered_df = pd.read_sql_query(
                    sql=text(kills_df_query), con=conn, params={"matchId": matchId})

            # require at least 1 kill in the dataset
            if len(filtered_df) > 0:
                # add traces
                fig: go.Figure = ff.create_quiver(
                    x=filtered_df["k_x"].to_numpy(),
                    y=filtered_df["k_y"].to_numpy(),
                    u=(filtered_df["v_x"] - filtered_df["k_x"]).to_numpy(),
                    v=(filtered_df["v_y"] - filtered_df["k_y"]).to_numpy(),
                    scale=1, arrow_scale=0.02, scaleratio=1, line=dict(color="rgba(0, 0, 0, 0.5)", width=1), name="Sightline")
                print(len(filtered_df))
                fig.add_trace(go.Scatter(x=filtered_df["k_x"], y=filtered_df["k_y"],
                                         opacity=0.5, mode='markers', name='Killer Locations', marker_color='#E66100', marker_symbol='square'))
                fig.add_trace(go.Scatter(x=filtered_df["v_x"], y=filtered_df["v_y"],
                                         opacity=0.5, mode='markers', name='Victim Locations', marker_color='#5D3A9B', marker_symbol="x"))

                # Add background image
                fig.add_layout_image(
                    dict(
                        source=mapImg,
                        xref="x",
                        yref="y",
                        x=0,
                        y=1,
                        sizex=1,
                        sizey=1,
                        sizing="stretch",
                        opacity=0.5,
                        layer="below")
                )
                # move legend to top left
                fig.update_layout(legend=dict(
                    yanchor="top",
                    y=0.99,
                    xanchor="left",
                    x=0.01
                ))
                fig.update_layout(
                    transition_duration=200, title=f"{mapName}, {len(filtered_df)} kills, {matchId}")

                # set the line on the first kill of the match
                first = filtered_df.iloc[0]
                x0, y0, x1, y1 = first["k_x"], first["k_y"], first["v_x"], first["v_y"]

                fig.add_shape(type="line", editable=True,
                              x0=x0, y0=y0, x1=x1, y1=y1,
                              line=dict(color="#32EE01", width=3)
                              )
                fig.add_trace(go.Scatter(x=[x0], y=[y0], mode='markers', marker=dict(
                    color='#E66100', size=14, symbol='square'), name='Killer'))
                fig.add_trace(go.Scatter(x=[x1], y=[y1], mode='markers', marker=dict(
                    color='#5D3A9B', size=14, symbol='x'), name='Victim'))

                fig.update_xaxes(showgrid=False)
                fig.update_yaxes(showgrid=False)

                first_fight_prob = gunfight_inference(x0, y0, x1, y1, mapName)
                probability_indicator = go.Indicator(
                    domain={'x': [0, 0.1], 'y': [0, 0.1]},
                    value=first_fight_prob,
                    mode="number+delta",
                    title={'text': "KP"},
                    delta={'reference': 50, 'suffix': '%'},
                    name='Kill Probability (KP)',
                    number={'suffix': '%'}
                )
                fig.add_trace(probability_indicator)

                return fig
        elif ctx.triggered_id == "graph":
            if 'layout' in fig and 'shapes' in fig['layout'] and 'shapes' in str(relayoutData):
                shapes = fig['layout']['shapes']
                # convert to go object to apply annotations
                fig: go.Figure = go.Figure(fig)
                s = shapes[0]
                fig.update_traces(x=[s['x0']], y=[s['y0']],
                                  selector=dict(name='Killer'))
                fig.update_traces(x=[s['x1']], y=[s['y1']],
                                  selector=dict(name='Victim'))
                
                # perform inference on the gunfight
                new_prob = gunfight_inference(s['x0'], s['y0'], s['x1'], s['y1'], mapName)
                fig.update_traces(value=new_prob,
                                  selector=dict(name='Kill Probability (KP)'))
                return fig
            else:
                return dash.no_update
    return go.Figure()


def gunfight_inference(k_x, k_y, v_x, v_y, mapName) -> float:
    print(f'k_x: {k_x}, k_y: {k_y}, v_x: {v_x}, v_y: {v_y}, mapName: {mapName}')
    variance = 0.2
    value = 0.5 + (random.random() * variance - variance / 2)
    return value * 100

@app.callback(
    Output('relay-data', 'children'),
    Input('graph', 'relayoutData'),
    State('graph', 'figure'),
)
def display_relayout_data(relayoutData, fig: dict):
    if 'layout' in fig and 'shapes' in fig['layout'] and 'shapes' in str(relayoutData):
        shapes = fig['layout']['shapes']

        return json.dumps(shapes, indent=2)
    return dash.no_update


if __name__ == '__main__':
    app.run_server(debug=True)
