from db_helper import get_db_cursor, create_kills_table, update_maps_table
from processor import process_match

mydb, cursor = get_db_cursor()
create_kills_table(cursor)
update_maps_table(cursor)
mydb.commit()

i = 0
# process kills
cursor.execute("SELECT * FROM matches")
row = cursor.fetchone()
while row is not None:
    if i % 100 == 0:
        print(i, row[0])
    # process using new cursor
    process_match(mydb, json_bytes=row[1])
    mydb.commit()
    # iterate and go to next row
    row = cursor.fetchone()
    i += 1


cursor.close()
mydb.close()
