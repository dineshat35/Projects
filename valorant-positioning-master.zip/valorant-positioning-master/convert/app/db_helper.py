import mysql.connector
from mysql.connector import errorcode
import time
from urllib.request import urlopen
import json


def create_kills_table_if_not_exists(cursor, table_query):
    # create the kills table if it doesn't exist
    try:
        print("Creating table {}: ".format("kills"), end='')
        cursor.execute(table_query)
        cursor.execute("CREATE INDEX idx_matchId ON kills (matchId)")
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")


def create_kills_table(cursor):
    kills = (
        "CREATE TABLE `kills` ("
        "  `k_x` DOUBLE NOT NULL,"  # killer x coord
        "  `k_y` DOUBLE NOT NULL,"  # killer y coord
        "  `k_atk_def` CHAR(3) NOT NULL,"  # killer atk or def
        "  `v_x` DOUBLE NOT NULL,"  # victim x coord
        "  `v_y` DOUBLE NOT NULL,"   # victim y coord
        "  `v_atk_def` CHAR(3) NOT NULL,"  # killer atk or def
        "  `matchId` CHAR(36) NOT NULL,"   # match uuid
        "  `map` VARCHAR(100) NOT NULL,"   # mapURL
        "  `roundNum` TINYINT NOT NULL,"   # round number
        "  `time_since_round_start` DOUBLE NOT NULL"   # seconds since round start
        ") ENGINE=InnoDB")
    create_kills_table_if_not_exists(cursor, table_query=kills)


def get_db_cursor():
    '''Sets up the connection and creates kills table if it doesn't exist'''

    db_config = {
        'user': 'root',
        'password': 'root',
        'host': 'db',
        'port': '3306',
        'database': 'matches'
    }

    max_retries = 10
    db_delay = 5
    i = 0

    while (i < max_retries):
        try:
            # connect to the mysql database
            mydb = mysql.connector.connect(**db_config)
            i = max_retries  # connection successful, break out
        except:
            print(
                f"Waiting for the mysql database to start... {i}")
            time.sleep(db_delay)
            i += 1

    cursor = mydb.cursor(buffered=True)

    return mydb, cursor


def get_maps():
    ''' Grabs the data for converting x, y data to usable coordinates '''
    maps_api_url = "https://valorant-api.com/v1/maps"
    response = urlopen(maps_api_url)
    # storing the JSON response
    data_json = json.loads(response.read())
    return data_json["data"]


def update_maps_table(cursor):
    ''' Delete existing maps table, then add all map stats needed '''
    maps_list = get_maps()
    # Drop the maps from the database if they exist
    drop_maps = ("DROP TABLE IF EXISTS maps")
    cursor.execute(drop_maps)
    # Create the new maps table
    maps = (
        "CREATE TABLE `maps` ("
        # '7eaecc1b-4337-bbf6-6ab9-04b8f06b3319'
        "  `uuid` CHAR(36) NOT NULL,"
        "  `displayName` VARCHAR(30) NOT NULL,"   # Ascent
        # 'https://media.valorant-api.com/maps/7eaecc1b-4337-bbf6-6ab9-04b8f06b3319/displayicon.png'
        "  `displayIcon` VARCHAR(100) NOT NULL,"
        "  `mapUrl` VARCHAR(60) NOT NULL,"   # '/Game/Maps/Ascent/Ascent'
        "  `xMultiplier` DOUBLE NOT NULL,"   # 7e-05
        "  `yMultiplier` DOUBLE NOT NULL,"   # -7e-05
        "  `xScalarToAdd` DOUBLE NOT NULL,"   # 0.813895
        "  `yScalarToAdd` DOUBLE NOT NULL"   # 0.573242
        ") ENGINE=InnoDB")
    cursor.execute(maps)
    sql = "INSERT INTO maps (uuid, displayName, displayIcon, mapUrl, xMultiplier, yMultiplier, xScalarToAdd, yScalarToAdd) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    for m in maps_list:
        val = (m["uuid"], m["displayName"], m["displayIcon"], m["mapUrl"],
               m["xMultiplier"], m["yMultiplier"], m["xScalarToAdd"], m["yScalarToAdd"])
        # check that all values are not None (this eliminates The Range from list)
        if not any(map(lambda x: x is None, val)):
            cursor.execute(sql, val)
            print(f"{m['displayName']} added")
