import zlib
import json
import math


def kills_processed(cursor, matchId):
    # ChatGPT actually came up with this one. Went from 0.64 s per query to 0.02 s per query.
    cursor.execute("SELECT 1 FROM dual WHERE EXISTS (SELECT 1 FROM kills WHERE matchId = (%s)) LIMIT 1", (matchId,))
    exists = cursor.fetchone()
    return exists is not None


def process_match(mydb, json_bytes):
    cursor = mydb.cursor()  # new cursor
    match_bytes = zlib.decompress(json_bytes)
    match_json = json.loads(match_bytes)

    if match_json["matchInfo"]["isCompleted"] and not kills_processed(mydb.cursor(), match_json["matchInfo"]["matchId"]):
        sql = "INSERT INTO kills (k_x, k_y, k_atk_def, v_x, v_y, v_atk_def, \
                matchId, map, roundNum, time_since_round_start) \
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        kill_vectors = get_kill_vectors(mydb.cursor(), match_json)
        cursor.executemany(sql, kill_vectors)
        cursor.close()


def round_num_to_atk_def(round_num):
    """Returns 0 if red is attacking, 1 if red is defending."""
    # zero-indexed rounds
    if round_num < 12:
        return 0
    elif 12 <= round_num < 24:
        return 1
    elif 24 <= round_num:
        return round_num % 2


def get_team_id(players_json, puuid):
    for p in players_json:
        if p["puuid"] == puuid:
            return p["teamId"]
    return "unknown"  # somehow the teamId is not in the list


def killer_location(k_puuid, player_locations):
    for pl in player_locations:
        if pl["puuid"] == k_puuid:
            pl_loc = pl["location"]
            k_x, k_y = pl_loc["x"], pl_loc["y"]
            return k_x, k_y
    return -math.inf, -math.inf


def get_atk_def(team_color, red_blue_atk_def):
    # red_blue_atk_def is 0 when red is attacking
    # red_blue_atk_def is 1 when red is defending
    if (team_color == "Red" and red_blue_atk_def == 0) or (team_color == "Blue" and red_blue_atk_def == 1):
        return "atk"
    else:
        return "def"


def scaled(cursor, mapUrl, x, y):
    # yes, this is correct
    # source: https://github.com/LouisAsanaka/Valorant-Zone-Stats/blob/7b6f67bb493626de6fd8a9a9d722557ee8df9f6f/src/models/models.py#L74
    map_query = "SELECT xMultiplier, yMultiplier, xScalarToAdd, yScalarToAdd FROM maps WHERE mapUrl = (%s) LIMIT 1"
    val = (mapUrl,)
    cursor.execute(map_query, val)
    xM, yM, xS, yS = cursor.fetchone()

    new_x = y * xM + xS
    new_y = x * yM + yS
    # yes this is correct too for drawing on the map
    new_y = 1 - new_y
    return new_x, new_y


def get_kill_vectors(cursor, match_json):
    players = match_json["players"]
    mapId = match_json["matchInfo"]["mapId"]
    matchId = match_json["matchInfo"]["matchId"]
    roundResults = match_json["roundResults"]
    features = []

    for r in roundResults:
        # attack or defend
        atk_def = round_num_to_atk_def(r["roundNum"])
        for player in r["playerStats"]:

            for kill in player["kills"]:
                if kill["finishingDamage"]["damageType"] == "Weapon":
                    player_locations = kill["playerLocations"]
                    orig_k_x, orig_k_y = killer_location(
                        kill["killer"], player_locations)
                    k_x, k_y = scaled(cursor, mapId, orig_k_x, orig_k_y)

                    k_team_id = get_team_id(
                        players, kill["killer"])  # Red or Blue
                    k_atk_def = get_atk_def(k_team_id, atk_def)

                    victim_location = kill["victimLocation"]
                    v_x, v_y = scaled(
                        cursor, mapId, victim_location["x"], victim_location["y"])
                    v_team_id = get_team_id(
                        players, kill["victim"])  # Red or Blue
                    v_atk_def = get_atk_def(v_team_id, atk_def)

                    # convert to seconds
                    time_since_round_start = kill["timeSinceRoundStartMillis"] * 0.001

                    # could find the player
                    if k_x != -math.inf and k_y != -math.inf:
                        k_params = [k_x, k_y, k_atk_def]
                        v_params = [v_x, v_y, v_atk_def]
                        meta_params = [matchId, mapId,
                                       r["roundNum"], time_since_round_start]

                        features.append(k_params + v_params + meta_params)

    return features
